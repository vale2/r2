

int mixerh=0;
int mixerw=0;
int *mixerbuf=NULL;
int *mul_mixerw;

void closeRgbMixer(){
    if(mixerbuf!=NULL){
        free(mixerbuf);
    }
    if(mul_mixerw!=NULL)
        free(mul_mixerw);
}

int ks0[256];
int ks1[256];
int ks2[256];

void calcKs(double alpha,int w,int mul){
    int x;
    for(x=0;x<256;x++){
        ks0[x]=4*(
        
                       (
                         (int)
                            (
                              sin(alpha)*x*mul/255
                            )
                       ) + 
                       (
                         (int)
                         (
                             (w+20)*
                             (
                                 (int)
                                 (
                                     cos(alpha)*x*mul/255
                                 )
                             )
                         )
                         
                       ) 
                            
                   );    //red y
        ks1[x]=1+4*(
        
                        (
                          (int)
                          (
                             sin(alpha+2.0*M_PI/3.0)*x*mul/255)
                          )+ 
                          (
                                (int)(20+w)*
                                    (
                                       (int)(
                                             cos(alpha+2.0*M_PI/3.0)
                                             *x*mul/255
                                             )
                                       )
                    
                    
                          )
                    );   //green x

        ks2[x]=2+4*(
                         (
                            (int)
                                   (    
                                      sin(alpha+4.0*M_PI/3.0)
                                      *x*mul/255
                                    )
                          )  +   
                          (
                              (int)
                              (20+w)*
                              (    (int)
                                  (
                                  cos(alpha+4.0*M_PI/3.0)*x*mul/255)
                                  )
                              
                           )   
                              );   //blue x
        
        
   }


}

int rgbMixer(SDL_Surface* source,SDL_Surface* filter,int mul,double alpha){
    int x,y;
    int bpp = source->format->BytesPerPixel;
    int r,g,b,fr,fg,fb,dx,dy;
    SDL_Surface *f,*s,*d;
    int *bu;
  //  printf("mixer start\n");
   // fflush(stdout);
    
    if(source->w!=filter->w || source->h!=filter->h
       
    
    ){
        if(mixerh!=-1){
           printf("Cant rgbMix, becouse screens are different\n");
           mixerh=-1;           
        }
        return -1;
    }
    if(mixerh!=filter->h || mixerw!=filter->w){

        if(mixerbuf!=NULL){
            free(mixerbuf);        
        }
        
        mixerbuf=(int*)malloc((filter->h+20)*(filter->w+20)*sizeof(int)*4);
        if(mixerbuf==NULL){
             printf("Cant rgbMix, becouse out of memory\n");
            return -2;
        }
        
        mixerh=filter->h;
        mixerw=filter->w;
       
    }
    memset(mixerbuf,0,(20+mixerh)*(20+mixerw)*4*sizeof(int));
    
   // bu=mixerbuf+(20+mixerw)*4*sizeof(int));
    calcKs(alpha,filter->w,mul);
    for(y=0;y<mixerh;y++){

        Uint32 *s =(Uint32 *)( (Uint8 *)source->pixels + y * source->pitch);
        Uint32 *f =(Uint32 *)( (Uint8 *)filter->pixels + y * filter->pitch);
        bu=mixerbuf+(((y+10)*(mixerw+20))+10)*4;
        for(x=mixerw-1;x;x--,bu+=4,f++,s++){
            if(!(*s) || !(*f)){
                continue;
            }
            pixel2rgb(*s,r,g,b);
            pixel2rgb(*f,fr,fg,fb);
            
            *s=0;
            bu[ks0[fr]]+=r;
            bu[ks1[fg]]+=g;
            bu[ks2[fb]]+=b;
            
        }
    }
    for(y=0;y<mixerh;y++){
        
        Uint32 *d =(Uint32*)( (Uint8 *)source->pixels + y * source->pitch);
        bu=mixerbuf+(((y+10)*(mixerw+20))+10)*4;
        for(x=mixerw-1;x;x--,bu++,d++){
            if(!((Uint32*)bu))
                continue;
            pixel2rgb(*d,r,g,b);
            r+=*bu;bu++;
            g+=*bu;bu++;
            b+=*bu;bu++;            
            if(r & (65535-255))
                r=255;           
            if(g& (65535-255))
                g=255;
            if(b& (65535-255))
                b=255;
            rgb2pixel(r,g,b,d);    
        }
    }

   // printf("mixer finish\n");
    //fflush(stdout);
    return 0;
}
