
SDL_Surface* sc;
int pifColor=0;
int naked=0;
int pifagorWind;
#define PIFEPS 0.1
#define NUMBER(a)   (((a)/1024))
#define MUL(a,b)    ((a*b)/1024)
#define TOFIXED(a)  ((int)(a))*1024)


int SQRT[1024];
int COS[1024]; //1023= 2*pi
int SIN[1024]; //1023= 2*pi
int ATAN2[512][512];
int initPifFlag=0;
void initPifTables(){
    int i,j;
    if(initPifFlag)
        return;
    initPifFlag=1;
    for(i=0;i<1024;i++){
        COS[i]=1024*cos(i*M_PI*2.0/1024.0);
        SIN[i]=1024*cos(i*M_PI*2.0/1024.0);
        SQRT[i]=1024*sqrt(i);
    }
    ATAN2[256][256]=0;
    for(i=0;i<512;i++)
        for(j=0;j<512;j++){
            if(i | j)
                ATAN2[i][j]=1024*atan2((i-256),(j-256))/(M_PI*2.0);
            while(ATAN2[i][j]<0)
                ATAN2[i][j]+=1024;
            ATAN2[i][j]&=1023;
            
        }

}


void QPif(int x1,int y1,int x2,int y2,int deep){
    int x;
    int y;
    int a,l,ll1,ll2;
    
    if((NUMBER(x1-x2)==0 && NUMBER(y1-y2)==0) || deep==0)
        return;
    x=x2-x1;
    y=y2-y1;
    a=ATAN2[NUMBER(y)][NUMBER(x)];
    
    l=SQRT[NUMBER(MUL(x,x)+MUL(y,y))];
    ll1=MUL(l,cosPifagorWind);
    x=MUL(COS[(a+3*511/2)&1023],l);
    y=MUL(COS((a+3*511/2)&1023],l);
    if(!naked){
        drawLine(sc,NUMBER(x1),NUMBER(y1),NUMBER(x1+x),NUMBER(y1+y),pifColor);
        drawLine(sc,NUMBER(x2),NUMBER(y2),NUMBER(x2+x),NUMBER(y2+y),pifColor);
        drawLine(sc,NUMBER(x1+x),NUMBER(y1+y),NUMBER(x2+x),NUMBER(y2+y),pifColor);
        drawLine(sc,NUMBER(x1),NUMBER(y1),NUMBER(x2),NUMBER(y2),pifColor);
    }
    
    
    //SDL_Flip( sc ); 
    //sleep(1);
    x1+=x;
    y1+=y;
    x2+=x;
    y2+=y;
    
  //  pifagorWind=M_PI/4;
    x=MUL(COS[(1023+a-pifagorWind]&1023),ll1);
    y=MUL(COS[(1023+a-pifagorWind]&1023),ll1);
    QPif(x1,y1,x1+x,y1+y,deep-1);
    
    
   // x=cos(M_PI-(a-pifagorWind))*ll2;
   // y=sin(M_PI-(a-pifagorWind))*ll2;
    QPif(x1+x,y1+y,x2,y2,deep-1);
  // QPif(x2+y,y2-x,x2,y2,deep-1);    
    
    //(x1,y1)
    //(x2,y1)
    
   // drawSqr(sc,x1,y1,x2,y2,pifColor);
    


}


void drawPifagor(SDL_Surface* screen,int deep,int n,double wind){
    sc=screen;
    pifColor=WHITE;
    naked=n;
    pifagorWind=wind*1024.0/(2.0*M_PI);
    while(pifagorWind<0)                 ///turning angle to special FIXED format
        pifagorWind+=1024;   /// and checking range
    pifagorWind&=1023;
    
    
    initPifTables();
    QPif(TOFIXED(sc->w/2-sc->w/15),TOFIXED(sc->h-1),TOFIXED(sc->w/2+sc->w/15),TOFIXED(sc->h-1),deep);
    

    
}
