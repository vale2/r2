#include "SDL/SDL.h"
#include <stdio.h>
#include <math.h>
#include <strings.h>
#include <memset.h>
#include "pipeutil.c"



int main(){
    char s[1024];
    while(1){
        scanf("%s",s);
        if(!strcmp(s,"quit")){
            break;        
        }
        printf("<<%s\n",s);
        CputData(s,strlen(s));
        memset(s,0,1024)
        CgetData(s,1023);       
        printf(">>%s\n",s);
    }



    return 0;
}
