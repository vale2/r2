struct splash{
    int x,y,state,duration,r;
    struct splash* next;
}*splashes=NULL;
struct rgb{
Uint8 r,g,b,o; 
};


struct rgb hsv2rgb(int h,double s,double v){// h =0.. 360  s=0..1  v=0..1
    int h1;
    double x,c,m,r,g,b;    
    struct rgb res;
    c=v*s;
    h1=h / 60;
    x=c*(1-abs((h1%2) - 1));    
    switch (h1){
        case 0:r=c ; g=x ; b=0 ;break;
        case 1:r=x ; g=c ; b=0 ;break;
        case 2:r=0 ; g=c ; b=x ;break;
        case 3:r=0 ; g=x ; b=c ;break;
        case 4:r=x ; g=0 ; b=c ;break;
        case 5:r=c ; g=0 ; b=x ;break;
    }
    m=v-c;
    r+=m;
    g+=m;
    b+=m;
    res.r=r*255;
    res.g=g*255;
    res.b=b*255;
    return res;
}




void addpixel(SDL_Surface *surface, int x, int y, Uint32 pixel,Uint32 mask)
{
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

   if((*(Uint32 *)p + pixel)&mask > (*(Uint32 *)p)&mask){
    *(Uint32 *)p += pixel;
   }else{
    (*(Uint32 *)p)&=mask;
   
   }
}


void addSplash(int x,int y,int r){
    struct splash*s;
    s=(struct splash*)malloc(sizeof(struct splash));
    if(s==NULL)
        return;
    s->next=splashes;
    s->x=x;
    s->y=y;
    s->state=0;
    s->duration=2;
    s->r=r;
    splashes=s;
}

void drawSplashes(SDL_Surface *sc){
    struct splash* s;
    int x,y,r;
    for(s=splashes;s;s=s->next){
        if(s->state==0){
            s->state++;
            for(x=-s->r;x<=s->r;x++)
                for(y=-s->r;y<=s->r;y++){
                    if(s->x+x>=0 && s->x+x<W&&s->y+y>=0&&s->y+y<H&&
                    
                    
                    x*x+y*y<s->r*s->r){
                        r=s->r*s->r - x*x+y*y;
                        r=r*255/r;
                        r=r | r<<8 | r<<16;
                        
                        addpixel(sc,s->x+x,s->y+y,r,255 | 255<<8 | 255<<16);    
                    
                    }
                    
                
                }
            
        
        }else{
            
        
        }
    
    }

}

unsigned int  inline getpixel(SDL_Surface *surface, int x, int y)
{
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
    unsigned int *q;
    q=(unsigned int*)p;
    return *q;
}


void inline putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}

unsigned int inline  viewPixel(SDL_Surface *sc,int x,int y){
    if(x>=0&&x<sc->w && y>=0 && y< sc->h){
        return getpixel(sc,x,y);
    
    }
    return 0;
}

void setPixel(SDL_Surface *sc,int x,int y,int c){
    if(x>=0&&x<sc->w && y>=0 && y< sc->h){
        putpixel(sc,x,y,c);
    
    }

}
void drawLine(SDL_Surface *sc,int x1, int y1, int x2, int y2,int c) {
    const int deltaX = abs(x2 - x1);
    const int deltaY = abs(y2 - y1);
    const int signX = x1 < x2 ? 1 : -1;
    const int signY = y1 < y2 ? 1 : -1;
    //
    int error = deltaX - deltaY;
    //
    setPixel(sc, x2, y2, c);
    while(x1 != x2 || y1 != y2) {
        setPixel(sc,x1, y1,c);
        const int error2 = error * 2;
        //
        if(error2 > -deltaY) {
            error -= deltaY;
            x1 += signX;
        }
        if(error2 < deltaX) {
            error += deltaX;
            y1 += signY;
        }
    }
 
}

void drawColoredLine(SDL_Surface *sc,int x1, int y1, int x2, int y2,Uint32(*colorSeq)()) {
    const int deltaX = abs(x2 - x1);
    const int deltaY = abs(y2 - y1);
    const int signX = x1 < x2 ? 1 : -1;
    const int signY = y1 < y2 ? 1 : -1;
    //
    int error = deltaX - deltaY;
    //
    setPixel(sc, x2, y2, (*colorSeq)());
    while(x1 != x2 || y1 != y2) {
        setPixel(sc,x1, y1,(*colorSeq)());
        const int error2 = error * 2;
        //
        if(error2 > -deltaY) {
            error -= deltaY;
            x1 += signX;
        }
        if(error2 < deltaX) {
            error += deltaX;
            y1 += signY;
        }
    }
 
}


inline void pixel2rgb(Uint32 p,int &r,int &g,int &b){
    
    
    r=((struct rgb*)(&p))->r;
    g=((struct rgb*)(&p))->g;
    b=((struct rgb*)(&p))->b;
}
inline void rgb2pixel(int r,int g,int b,Uint32 *p){
//    *p=(((Uint32)g)*65536+b)*65536+r;
       ((struct rgb*)p)->r=r;
       ((struct rgb*)p)->g=g;
       ((struct rgb*)p)->b=b;
       


}

SDL_Surface *cloneScreen(SDL_Surface *screen){
    const SDL_PixelFormat& fmt = *(screen->format);
  return SDL_CreateRGBSurface(screen->flags,screen->w,screen->h,
                  fmt.BitsPerPixel,
                  fmt.Rmask,fmt.Gmask,fmt.Bmask,fmt.Amask );


}


