#!/bin/sh
nc -l 1234 -k| ./a.out | nc -l 1235 -k

