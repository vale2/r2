
SDL_Surface* sc;
int pifColor=0;
int naked=0;
double pifagorWind;
double cospifagorWind;
int staticcolor=1;



#define PIFEPS 1.
#define NUMBER(a)   ((((a)+512)/1024))
//#define TOFIXED(a)  


int SQRT[30000];
int COS[1024]; //1023= 2*pi
int SIN[1024]; //1023= 2*pi
int ATAN2[512][512];
int initPifFlag=0;


inline int TOFIXED(double a){
    return     (int)(a*1024.0);


}

Uint64 a,b;
int sig;

inline int MULT(int aa,int bb){
    
    
    return (aa*bb/1024);/*
    if(aa>0&&bb>0){
        sig=1;
        a=aa;
        b=bb;
    }else if(aa<0&&bb<0){
        sig=1;
        a=-aa;
        b=-bb;
    }else
    if(aa<0&&bb>0){
        sig=-1;
        a=-aa;
        b=bb;
    
    }else{
        sig=-1;
        a=aa;
        b=-bb;
    }
        return     sig*((int)(a*b/1024));
        */
//
}

#define INF 1e100;
double pMaxx=-INF;
double pMaxy=-INF;
double pMinx=INF;
double pMiny=INF;
double pscale;
#define max(a,b) ((a)>(b))?(a):(b)
double piftimes=0.;
int sh,sw;
double maxl=1000.0;
void initPifTables(double w,double h){
    int i,j;
    /*double lpscale;
    lpscale=pscale;
    if(pMaxx>pMinx && pMiny<pMaxy){
        pscale=min(w/(pMaxx-pMinx),h/(pMaxy-pMiny))*2;        
    }else
        pscale=1;
   pscale=pscale*0.6+lpscale*0.4;
  */
  
   sh=h-1;
   sw=w-1;
   
 
    
    
    if(initPifFlag)
        return;
    initPifFlag=1;
    for(i=0;i<1024;i++){
        COS[i]=1024.0*cos(i*M_PI*2.0/1024.0);
        SIN[i]=1024.0*sin(i*M_PI*2.0/1024.0);

    }
    for(i=0;i<30000;i++)
        SQRT[i]=1024.0*sqrt((double)i);
    ATAN2[256][256]=0;
    for(i=0;i<512;i++)
        for(j=0;j<512;j++){
            if(i | j)
                ATAN2[i][j]=1024.0*atan2((i-256),(j-256))/(M_PI*2.0);
            while(ATAN2[i][j]<0)
                ATAN2[i][j]+=1024;
            ATAN2[i][j]&=1023;
            
        }

}


void QPif(double x1,double y1,double x2,double y2,int deep){
    double x,xx,yy,xx1,xx2,yy1,yy2;
    double y;
    double a,l,ll1,ll2;
    
    if(/*(fabs(x1-x2)<PIFEPS && fabs(y1-y2)<PIFEPS) ||*/ deep==0)
        return;
  /*  if(x1<pMinx)
        pMinx=x1;
    if(x2<pMinx)
        pMinx=x2;
    if(x1>pMaxx)
        pMaxx=x1;
    if(x2>pMaxx)
        pMaxx=x2;
    if(y1<pMiny)
        pMiny=y1;
    if(y2<pMiny)
        pMiny=y2;
    if(y1>pMaxy)
        pMaxy=y1;
    if(y2>pMaxy)
        pMaxy=y2;
    */    
    x=x2-x1;
    y=y2-y1;
    
   // a=ATAN2[NUMBER(y)+256][NUMBER(x)+256];
     a=atan2(y,x);
     l=sqrt((x*x)+(y*y));
    ll1=l*cospifagorWind;
    x=cos(a -M_PI/2)*l;
    y=sin(a -M_PI/2)*l;
    
    
    
    xx1=x1+x;
    yy1=y1+y;
    xx2=x2+x;
    yy2=y2+y;
    
  //  pifagorWind=M_PI/4;
    xx=cos(a-pifagorWind)*ll1;
    yy=sin(a-pifagorWind)*ll1;
    
    
    if(!naked){
        if(l<maxl){
            if(staticcolor){  
        
        
                drawLine(sc,(x2),(y2),(x2+x),(y2+y),pifColor);
                drawLine(sc,(x1),(y1),(x1+x),(y1+y),pifColor);
                drawLine(sc,(x1+x),(y1+y),(x2+x),(y2+y),pifColor);
                drawLine(sc,(x1),(y1),(x2),(y2),pifColor);
   
                drawLine(sc,sw-(x2),sh-(y2),sw-(x2+x),sh-(y2+y),pifColor);
                drawLine(sc,sw-(x1),sh-(y1),sw-(x1+x),sh-(y1+y),pifColor);
                drawLine(sc,sw-(x1+x),sh-(y1+y),sw-(x2+x),sh-(y2+y),pifColor);
                drawLine(sc,sw-(x1),sh-(y1),sw-(x2),sh-(y2),pifColor);
   
   
            }else{
                drawColoredLine(sc,(x2),(y2),(x2+x),(y2+y),colorSeq2);
                drawColoredLine(sc,(x1),(y1),(x1+x),(y1+y),colorSeq2);
                drawColoredLine(sc,(x1+x),(y1+y),(x2+x),(y2+y),colorSeq2);
                drawColoredLine(sc,(x1),(y1),(x2),(y2),colorSeq2);
    
  
                drawColoredLine(sc,sw-(x2),sh-(y2),sw-(x2+x),sh-(y2+y),colorSeq2);
                drawColoredLine(sc,sw-(x1),sh-(y1),sw-(x1+x),sh-(y1+y),colorSeq2);
               drawColoredLine(sc,sw-(x1+x),sh-(y1+y),sw-(x2+x),sh-(y2+y),colorSeq2);
                drawColoredLine(sc,sw-(x1),sh-(y1),sw-(x2),sh-(y2),colorSeq2);
    
            }
        }
    }else{
                double tl,tx,ty;
                tx=(x1+x2)/2  -  (x1+x+x2+x)/2;
                ty=(y1+y2)/2  - (y1+y+y2+y)/2 ;
                
                 
                 if(tx*tx+ty*ty<maxl*maxl){
                    if(!staticcolor){
                         drawColoredLine(sc,(x1+x2)/2,(y1+y2)/2,(x1+x+x2+x)/2,(y1+y+y2+y)/2,colorSeq2);
                         drawColoredLine(sc,(x1+x+x2+x)/2,(y1+y+y2+y)/2,(xx1+xx1+xx)/2,(yy1+yy1+yy)/2,colorSeq2);
                         drawColoredLine(sc,(x1+x+x2+x)/2,(y1+y+y2+y)/2,(xx1+xx+xx2)/2,(yy1+yy+yy2)/2,colorSeq2);
                 
                 
                 
                         drawColoredLine(sc,sw-(x1+x2)/2,sh-(y1+y2)/2,sw-(x1+x+x2+x)/2,sh-(y1+y+y2+y)/2,colorSeq2);
                         drawColoredLine(sc,sw-(x1+x+x2+x)/2,sh-(y1+y+y2+y)/2,sw-(xx1+xx1+xx)/2,sh-(yy1+yy1+yy)/2,colorSeq2);
                         drawColoredLine(sc,sw-(x1+x+x2+x)/2,sh-(y1+y+y2+y)/2,sw-(xx1+xx+xx2)/2,sh-(yy1+yy+yy2)/2,colorSeq2);
                    }else{
                         drawLine(sc,(x1+x2)/2,(y1+y2)/2,(x1+x+x2+x)/2,(y1+y+y2+y)/2,pifColor);
                         drawLine(sc,(x1+x+x2+x)/2,(y1+y+y2+y)/2,(xx1+xx1+xx)/2,(yy1+yy1+yy)/2,pifColor);
                         drawLine(sc,(x1+x+x2+x)/2,(y1+y+y2+y)/2,(xx1+xx+xx2)/2,(yy1+yy+yy2)/2,pifColor);
                         drawLine(sc,sw-(x1+x2)/2,sh-(y1+y2)/2,sw-(x1+x+x2+x)/2,sh-(y1+y+y2+y)/2,pifColor);
                         drawLine(sc,sw-(x1+x+x2+x)/2,sh-(y1+y+y2+y)/2,sw-(xx1+xx1+xx)/2,sh-(yy1+yy1+yy)/2,pifColor);
                         drawLine(sc,sw-(x1+x+x2+x)/2,sh-(y1+y+y2+y)/2,sw-(xx1+xx+xx2)/2,sh-(yy1+yy+yy2)/2,pifColor);
                    
                    
                    }
                 
                 }             
//                 drawColoredLine(sc,(x1+x+x2+x)/2,(y1),(x1+x),(y1+y),colorSeq2);
               
               
    //            drawColoredLine(sc,(x1),(y1),(x1+x),(y1+y),colorSeq2);
      //          drawColoredLine(sc,(x1+x),(y1+y),(x2+x),(y2+y),colorSeq2);
        //        drawColoredLine(sc,(x1),(y1),(x2),(y2),colorSeq2);
    
    
    
    }
    //SDL_Flip( sc ); 
    //sleep(1);
    
    QPif(xx1,yy1,xx1+xx,yy1+yy,deep-1);
    
    
   // x=cos(M_PI-(a-pifagorWind))*ll2;
   // y=sin(M_PI-(a-pifagorWind))*ll2;
    QPif(xx1+xx,yy1+yy,xx2,yy2,deep-1);
  // QPif(x2+y,y2-x,x2,y2,deep-1);    
    
    //(x1,y1)
    //(x2,y1)
    
   // drawSqr(sc,x1,y1,x2,y2,pifColor);
    


}

double pifAngle=0;
#define BLUE 0x0000ff
void drawPifagor(SDL_Surface* screen,int deep,int n,int color,double dwind,double dpscale,double dpangle,double colorSpeedr,double colorSpeedg,double colorSpeedb){
    sc=screen;
    pifColor=WHITE;
    naked=n;
    //if(color){
        initColorSeq2(colorSpeedr,colorSpeedg,colorSpeedb);    
   // }
    staticcolor=color;
    //printf("Pifa:%lf\n",wind);
    //fflush(stdout);
    initColorSeq1();
    
    while(wind>M_PI*2)
        wind-=M_PI*2;
    while(wind<0.0)
        wind+=M_PI*2;
        
   // if(wind>M_PI&&wind<M_PI+M_PI/100)
     //   return;    
   //if(wind<M_PI&&wind>M_PI-M_PI/100)
     //   return; 
    //wind=-9*M_PI/20;
    
    
    
    
    
    
    pscale=ascell(1,piftimes)/10.0; 
    piftimes+=dpscale;
    pifagorWind=ascell(2,wind);
    wind+=dwind;
    pifAngle+=dpangle;
    
    
    maxl=sc->w*100./1366.;
   
    
    
    seqno2=0;
   // if(!(rand()%500)){
    //    naked=!naked;
    //}
    cospifagorWind=cos(pifagorWind);
    initPifTables(sc->w,sc->h);
    double x1,y1,x2,y2;
    x1=sc->w/2 +((sc->w/2-(sc->w/15)*pscale) - sc->w/2)*cos(pifAngle) + ((sc->h-1 - sc->h/2)*sin(pifAngle));
    y1=sc->h/2 + ((sc->h-1)-sc->h/2)*cos(pifAngle)   -  ((sc->w/2-(sc->w/15)*pscale) - sc->w/2)*sin(pifAngle);
    x2=sc->w/2 +((sc->w/2+(sc->w/15)*pscale) - sc->w/2)*cos(pifAngle) + ((sc->h-1 - sc->h/2)*sin(pifAngle));
    y2=sc->h/2 + ((sc->h-1)-sc->h/2)*cos(pifAngle)   -  ((sc->w/2+(sc->w/15)*pscale) - sc->w/2)*sin(pifAngle);
   // pifAngle+=;
    QPif(x1,y1,x2,y2,deep);
    //colorSeq2Len=seqno2;
  //  printf("%lld\n",colorSeq2Len);
//    QPif((sc->w/2-(sc->w/15)*pscale,(sc->h-1),(sc->w/2+(sc->w/15)*pscale),(sc->h-1),deep);
    //QPif(  sc->w-1,  sc->h/2-(sc->w/15)*pscale,sc->w-1,sc->h+(sc->h/15)*pscale,deep);

   // QPif((sc->w/2+(sc->w/15)*pscale),0,(sc->w/2-(sc->w/15)*pscale),0,deep);
    //QPif(0,sc->h/2+(sc->h/15)*pscale,0,sc->h-(sc->h/15)*pscale,deep);
   

    //printf("wind:%d deg\n",(int)(wind*180./M_PI));   
}
