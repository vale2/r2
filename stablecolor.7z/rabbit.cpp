#define WINDOWCOMPILE 0
#define NONBLOCK
//#define WINDOWCOMPILE 8
void *__gxx_personality_v0;

#include "SDL/SDL.h"
//#include "SDL_opengl.h"
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <time.h> 
#ifdef NONBLOCK
    #include <fcntl.h>
#endif

#include"ascillators.cpp"
#define BUFSIZE 128
int msgid;

struct msgp {
    long mtype;
    char s[128];

};

void*modeData;
int mode,H,W;
//#include<sys/ipc.h>
//#include<sys/msg.h>
//#include <sys/types.h>
#define SVIDKEY 7373
#define min(x,y)  (((x)>(y))?(y):(x))
#include "graphutil.cpp"
//#include "netutil.cpp"
//#include "pipeutil.c"
//#include <sys/socket.h>

#include "snake.cpp"
//  GLuint texture; // Texture object handle
#include "hohloma.cpp"
#include "4d.cpp"
#include "barcode.cpp"
//#include "slcf.cpp"
#include "piano.cpp"
#include "mixer.cpp"
#include "pifagor.cpp"
//int SVIDanswer(const char*p);
void drawStars(SDL_Surface* screen){
    putpixel(screen,rand() % (screen->w),rand() % (screen->h),rand()); 
    SDL_Flip( screen ); 
}


Uint64 frames=0;
int rgbMixerDepth=10;
int noiseC=0;
int noiseV=0;
int noiseColor=0;
int pifDeep=13;
int pifNaked=1;
int pifColored=1;
double pifDWind=1/100000.0;
double pifDScale=1;
double pifDAngle=M_PI/10000;
double pifColorSpeedr=0.01;
double pifColorSpeedg=0.01;
double pifColorSpeedb=0.01;
int faded=50;
void draw(SDL_Surface* screen,SDL_Surface* filter){
  // SDL_FillRect(screen,NULL, 0x000000);
 //  SDL_FillRect(filter,NULL, 0x000000);
    fade(screen,faded);
    addNoise(screen,noiseC,noiseV,noiseColor);
    switch (mode){
        case 1: drawSnake(screen); break;   
        case 2:drawHohloma(screen); break;      
        case 3:draw4d(screen); break;
        case 4:drawbarcode(screen); break;
        
        case 5: drawPifagor(screen,pifDeep,pifNaked,pifColored,pifDWind,pifDScale,pifDAngle,pifColorSpeedr,pifColorSpeedg,pifColorSpeedb);break;
        
        default: drawStars(screen); break;
    
    }
   // drawPifagor(filter,10+rand()%5);
   // drawPiano(filter,4+rand()%3);
   // addNoise(filter,10,255,0);
    
    rgbMixer(screen,filter,(rgbMixerDepth==11)?ascell(0,frames):rgbMixerDepth ,frames*M_PI/100.0);
    SDL_Flip( screen ); 
    frames++;
}
int moveTimes=1;
void move(){
int i,j;
    for(j=0;j<moveTimes;j++){
    switch(mode){
        case 1:for(i=0;i<3;i++) moveSnake();break;   
        case 2:moveHohloma();break;   
        case 3:move4d();break;
        case 4:movebarcode();break;   

    }

}
}
SDL_Surface* screen= NULL;
void setMode(int newMode){
        if(mode==2&&newMode!=2){
            closeHohloma();     
        }
        if(mode == 3 && newMode!=3){
            close4d();
        }
        if(mode == 4 && newMode!=4){
            checkBars();
        }
        
        switch(newMode){
            case 1:if(mode==1)
                    break;
                    
                if(modeData!=NULL){
                    free(modeData);
                }
                modeData=malloc(2*sizeof(snake));
                if(modeData!=NULL){
                    mode=1;
                    zeroSnake();                    
                }
                break;
              case 2:if(mode==2)
                        break;
                    mode=2;
                    zeroHohloma(screen);
                break;  
              case 3:if(mode==3)
                        break;
                    mode=3;
                    init4d();
                break;  
                case 4:if(mode==4)
                        break;
                    mode=4;
                    initbarcode(screen);
                break; 
                case 5:if(mode==5)
                        break;
                    mode=5;
                   // initslcf();
                break;
              default:if(mode==newMode)
                        break;
                    if(modeData!=NULL){
                        free(modeData);
                       
                    }
                    modeData=NULL;
                    mode=newMode;
                   break;   
            
            
        }


}

int checkSpace(char a){
    if(a==' '||a==10||a==13)
        return 1;
    return 0;
}
int skeep(char*p){
    int a=0;
    while(*p&&checkSpace(*p)){
        a++;
        p++;
    }
    while(*p&&!checkSpace(*p)){
        a++;
        p++;
    }
    while(*p&&checkSpace(*p)){
        a++;
        p++;
    }
//    if(a>0)
    return a;
  //  return 0;

}
int syntaxControll(char*p);

int execConfig(const char*s){
    FILE*f;
    char st[1024];
    f=fopen(s,"rt");
    if(f==NULL){
        printf("Can't exec \"%s\"\n",s);
        return 1;
    }
    while(!feof(f)){
        fgets(st,1023,f);
        syntaxControll(st);
    }
    fclose(f);
    return 1;
}
int syntaxControll(char*p){
    char term[128];
    char buf[128];
    int t1,i,t2;
    double t,a,z,f;
   // printf("SyntaxControll:%s\n",p);
    while(*p){
        sscanf(p,"%s",term);
        p+=skeep(p);
        
        if(!strcmp(term,"getmode")){
            printf("mode %d\n",mode);
            fflush(stdout);
           // SVIDanswer(buf);
        }
        if(!strcmp(term,"exec")){
           sscanf(p,"%s",buf);
           p+=skeep(p);
           execConfig(buf);
        }
        if(!strcmp(term,"exit")){
            printf("Exiting\n");
            return 1;
           // SVIDanswer(buf);
        }
        if(!strcmp(term,"setascell")){
            
           // //printf("(%s)\n",p);
           sscanf(p,"%d",&t1);
           p+=skeep(p);
           sscanf(p,"%d",&t2);
           p+=skeep(p);
           
           for(i=0;i<t2;i++){
             sscanf(p,"%lf",&t);
             p+=skeep(p);
             sscanf(p,"%lf",&a);
             p+=skeep(p);
             sscanf(p,"%lf",&z);
             p+=skeep(p);
             sscanf(p,"%lf",&f);
             p+=skeep(p);
             if(i==0){
                setAscellator(t1,t,a,z,f);
             }else{
                addAscellator(t1,t,a,z,f);
             }
           // printf("%lf %lf %lf %lf\n",t,a,z,f);
           }
           
           
//           printf("moveTimes:%d\n",moveTimes);
          //  p+=skeep(p);
//            setMode(t1,screen);
            
            
           // SVIDanswer(buf);
        }
        
        if(!strcmp(term,"movetimes")){
            
            //printf("(%s)\n",p);
            sscanf(p,"%d",&moveTimes);
           printf("moveTimes:%d\n",moveTimes);
            p+=skeep(p);
//            setMode(t1,screen);
            
            
           // SVIDanswer(buf);
        }
        if(!strcmp(term,"setnoise")){
           sscanf(p,"%d %d %d",&noiseC,&noiseV,&noiseColor);
           printf("noise:%d %d %d\n",noiseC,noiseV,noiseColor);
           p+=skeep(p);p+=skeep(p);p+=skeep(p);
           
        }
        
        if(!strcmp(term,"rgbmixer")){
            
            //printf("(%s)\n",p);
            sscanf(p,"%d",&rgbMixerDepth);
            if(rgbMixerDepth>11)
                rgbMixerDepth=11;
            if(rgbMixerDepth<0)
                rgbMixerDepth=0;
            printf("rgbMixerDepth:%d\n",rgbMixerDepth);
            p+=skeep(p);
//            setMode(t1,screen);
            
            
           // SVIDanswer(buf);
        }
        
        if(!strcmp(term,"setmode")){
            //printf("(%s)\n",p);
            sscanf(p,"%d",&t1);
            p+=skeep(p);
            setMode(t1);
       
            
        }
   
    }
    return 0;
}

char command[1024];
int ccur=0;
int controll(SDL_Surface *screen){
    SDL_Event event;
    char buf[BUFSIZE+1]="";
    int datasize;
    int msgid,size;
    struct msgp a;

    #ifdef NONBLOCK
       int c;
       c=getc(stdin);
       if(c!=EOF && c!=-1){

           if(c==10){
             //  printf("enter!\n");
              command[ccur]=0; 
              if(syntaxControll(command))
                return 1;
              ccur=0;
           }else{
               if(ccur<1023){
                   command[ccur++]=c;
               }else{
                   ccur=0;
               }
           }
       }
    #endif


   // size=msgrcv(msgid,&a,sizeof(struct msgp),1,IPC_NOWAIT );
    size=0;
    if(size>0 ){
         syntaxControll(a.s);
     }
    
    
    
    if(mode==1 && checkLokalSnake() && !(rand()%200)){
        setMode(0);
        setMode(1);  
    
    }
    
   /* if(mode==1 && !(rand()%1000)  && !(rand()%30)){
        setMode(0,screen);
        setMode(1,screen);
    }*/
    
    
    while(SDL_PollEvent(&event)){
        switch (event.type) {
            case SDL_KEYDOWN: switch (event.key.keysym.scancode){
                              case 9-WINDOWCOMPILE: return 1; break;//ESC
                              case 10-WINDOWCOMPILE: setMode(0); break;//1
                              case 11-WINDOWCOMPILE: setMode(1); break;//2
                              case 12-WINDOWCOMPILE: setMode(2); break;//3
                              case 13-WINDOWCOMPILE: setMode(3); break;//4
                              case 14-WINDOWCOMPILE: setMode(4); break;//5
                              case 15-WINDOWCOMPILE: setMode(5); break;//6
                              case 31:if(faded>20)
                                            faded-=10;
                                       else if(faded>10)
                                            faded-=2;
                                        else
                                            if(faded>0)
                                                faded--;
                              
                              
                               break;
                              case 32:
                              if(faded<10)
                                         faded++;
                                       else if(faded<20)
                                            faded+=2;
                                        else if(faded<255)
                                            faded+=10;
                                
                                
                                if(faded>255)
                                        faded=255;break;
                              
                              
                          //    case 27-WINDOWCOMPILE :      srand (time(NULL)); break;//r
                              
                              //RGBMIXER
                              case 33:if(rgbMixerDepth==11) rgbMixerDepth=ascell(0,frames);break;   // p
                              case 34:if(rgbMixerDepth && rgbMixerDepth!=11)rgbMixerDepth--;break;  // [
                              case 35: if(rgbMixerDepth<10)rgbMixerDepth++;break;                   // ]
                              case 51: rgbMixerDepth=11; break;                                     // \

                              ///NOISE   noiseC  0..100   ,noiseV 0..255  ,noiseColor 0..1
                              case 24:if(noiseC<100)noiseC++; break;                                // q
                              case 25:if(noiseV<255)noiseV++; break;                                // w
                              case 38:if(noiseC>0)noiseC--; break;                                  // a
                              case 39:if(noiseV>0)noiseV--; break;                                  // s
                              case 26:noiseColor=!noiseColor; break;                                // d
                              ///  PIFAGOR
                              //int pifDeep=13;int pifNaked=1;int pifColored=1;
                              case 52:if(mode==5)pifNaked=!pifNaked;break;                          // z
                              case 53:if(mode==5)pifColored=!pifColored;break;                      // x
                              case 54:if(mode==5)if(pifDeep)pifDeep--;break;                        // c
                              case 55:if(mode==5)if(pifDeep<16){pifDeep++; } printf("pifDeep:%d\n",pifDeep);break;                                   // v
                              //pifDWind,pifDScale,pifDAngle
                              case 46:if(mode==5)pifDWind*=1.1;break;                              // l
                              case 59:if(mode==5)pifDWind/=1.1;break;                               // ,
                              case 47:if(mode==5)pifDScale*=1.1;break;                             // ;
                              case 60:if(mode==5)pifDScale/=1.1;break;                             // .
                              case 48:if(mode==5)pifDAngle*=1.1;break;                            // '
                              case 61:if(mode==5)pifDAngle/=1.1;break;                             // /
                              case 56:if(mode==5)pifDWind*=-1;break;                              // b
                              case 57:if(mode==5)pifDScale*=-1;break;                              // n
                              case 58:if(mode==5)pifDAngle*=-1;break;                              // m
                              
                              case 27:if(mode==5)pifColorSpeedr*=1.1;break;                              // r
                              case 41:if(mode==5)pifColorSpeedr/=1.1;break;                              // f
                              case 28:if(mode==5)pifColorSpeedg*=1.1;break;                              // g
                              case 42:if(mode==5)pifColorSpeedg/=1.1;break;                              // f
                              case 29:if(mode==5)pifColorSpeedb*=1.1;break;                              // g
                              case 43:if(mode==5)pifColorSpeedb/=1.1;break;                              // g
                              
                              
                              
                              default:printf("keydown:%d \n",event.key.keysym.scancode); break;
                              }    break;
            
            
            case SDL_QUIT: return 1; break;
           
        }
    }
    
    
     
    
    
    
    return 0;
}
void initStdIn(){
#ifdef NONBLOCK

    int flags;
    flags = fcntl(0, F_GETFL); /* get current file status flags */
    flags |= O_NONBLOCK;		/* turn off blocking flag */
     fcntl(0, F_SETFL, flags);		/* set up non-blocking read */
 #endif

}

int main( int argc, char* args[] ) { 
    int i,x,y,c,flag,windowflag,windowXRes,windowYRes;
    //The images 
    SDL_Surface* hello = NULL; 
    //SDL_Surface* screen = NULL;
    SDL_Surface* filter = NULL;
    SDL_Surface *trueScreen = NULL ;
    const SDL_VideoInfo* myPointer;
    modeData=NULL;
    windowflag=0;
    flag=1;
    srand (time(NULL));
    SDL_putenv((char*)"SDL_VIDEO_WINDOW_POS=0,0");
    initStdIn();
    for(i=1;i<argc;i++){
        if(!strcmp(args[i],"-window") && i+1<argc){
            windowXRes=-1;
            windowYRes=-1;
            i++;
            sscanf(args[i],"%dx%d",&windowXRes,&windowYRes);
            if(windowXRes > 0 && windowYRes > 0 ){
                windowflag=1;  
                SDL_putenv((char*)"SDL_VIDEO_WINDOW_POS=50,50");
     
            }
        }
            
    
    }

    // initPipes();
     //Start SDL 
     SDL_Init( SDL_INIT_EVERYTHING ); 
     //Set up screen 
     
     
     zeroAsc();
     myPointer = SDL_GetVideoInfo();
     W=myPointer->current_w;
     H=myPointer->current_h;
     if(windowflag){
        W=windowXRes;
        H=windowYRes;
     }        
     screen = SDL_SetVideoMode(W , H, 32, SDL_HWSURFACE |  (windowflag?0:SDL_NOFRAME) | SDL_DOUBLEBUF/*|SDL_GL_DOUBLEBUFFER |SDL_OPENGL */); 
     filter=cloneScreen(screen);
     if(filter==NULL){
        printf("Cant create filter surface\n");
        return 1;
     }
     SDL_ShowCursor(0);
// drawPifagor(filter);
    drawPiano(filter,8);
     zerroTable();
     mode=0;
     G=6;
     L=0.0001;
     M=0.001;
     SNL=3;
     K=0.001;
     C=10;

     setMode(2);
     execConfig("config");
    // setNetcontroll();
     while(flag){
        //printf("draw\n");
       // fflush(stdout);
        draw(screen,filter);
        //printf("move\n");
       // fflush(stdout);
       // for(i=0;i<10;i++)
            move();
        if(controll(screen)){
            break;
        }       
        
     }
     

     
      //Quit SDL 
      closeRgbMixer();
      SDL_Quit(); 
      return 0;
}
