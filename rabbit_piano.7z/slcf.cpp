#define FRAQSPLIT 3
#define FRAQLEN 20
#define MINFRAQLEN 2
#define sign(a) (((a)>=0)?1:-1)

char map[FRAQSPLIT][FRAQSPLIT];
char fraqLR[FRAQLEN+5]; // 0-right 1-left 2-up 3-down  4-stop/////5-ur 6-ul 7-dr 8-dl  
char fraqLD[FRAQLEN+5];
char fraqLU[FRAQLEN+5];
char fraqUD[FRAQLEN+5];
char fraqRD[FRAQLEN+5];
char fraqRU[FRAQLEN+5];




char fraqRL[FRAQLEN+5];
char fraqDL[FRAQLEN+5];
char fraqUL[FRAQLEN+5];
char fraqDU[FRAQLEN+5];
char fraqDR[FRAQLEN+5];
char fraqUR[FRAQLEN+5];
char *fraqs[4][4];
void initFraqTables(){
    fraqs[1][0]=fraqLR;
    fraqs[1][2]=fraqLU;
    fraqs[1][3]=fraqLD;
    
    fraqs[0][1]=fraqRL;
    fraqs[0][2]=fraqRU;
    fraqs[0][3]=fraqRD;

    fraqs[2][1]=fraqUL;
    fraqs[2][0]=fraqUR;
    fraqs[2][3]=fraqUD;

    fraqs[3][1]=fraqDL;
    fraqs[3][0]=fraqDR;
    fraqs[3][2]=fraqDU;  


}




int checkPath(char*path){
    int i,x,y,ii,x1,x2,y1,y2;
    for(x=0;x<FRAQSPLIT;x++){
        for(y=0;y<FRAQSPLIT;y++){
            map[x][y]=0;
        }
    }
    x1=*path;path++;
    y1=*path;path++;
    x2=*path;path++;
    y2=*path;path++;
    x=x1;
    y=y1;
    map[x][y]=1;
    for(i=0,ii=0;i<FRAQLEN;i++,path++,ii++){
        switch(*path){
            case 4:i=FRAQLEN; continue; break;
            case 0:x++; break;
            case 1:x--; break;
            case 2:y--; break;
            case 3:y++; break;
           /* case 5:y--;x++; break;
            case 6:y--;x--; break;
            case 7:y++;x++; break;
            case 8:y++;x--; break;
            */
            default: return 0;        
        }
        if(x>=FRAQSPLIT || y>=FRAQSPLIT || x<0 || y<0){
            return 0;
        }
        if(map[x][y])
            return 0;
        map[x][y]=1;
    }
    if(x==x2 && y==y2 && ii > MINFRAQLEN)
        return 1;
    return 0;

}
void randPath(int x1,int y1,int x2,int y2,char *path){
    int i;
    int l;
    *path=x1;path++;
    *path=y1;path++;
    *path=x2;path++;
    *path=y2;path++;
    
    l=MINFRAQLEN+((FRAQLEN>MINFRAQLEN)?(rand()%(FRAQLEN-MINFRAQLEN)):0);
    for(i=0;i<l;i++,path++)
        *path=rand()%4;        
    
    *path=4; 
    
}


char back(char a){
    switch(a){
        case 0: return 1;break;
        case 1: return 0;break;
        case 2: return 3;break;
        case 3: return 2;break;
      /*  case 5: return 8;break;
        case 6: return 7;break;
        case 7: return 6;break;
        case 8: return 5;break;
    */
    }

}
void reverse(char*path,char*backpath){
    int i,j,x1,y1,x2,y2;
    x1=*path;path++;
    y1=*path;path++;
    x2=*path;path++;
    y2=*path;path++;
    *backpath=x2;backpath++;
    *backpath=y2;backpath++;
    *backpath=x1;backpath++;
    *backpath=y1;backpath++;
    
    
    for(i=0;i<FRAQLEN && *path!=4;i++,path++)
        printf("_%d_",(int)*path);
    path--;i--;
    printf("(%d)",i);
    fflush(stdout);
    for(j=0;i>=0;path--,backpath++,j++,i--){
        *backpath=back(*path);
        printf("+%d+",(int)*backpath);
    }
    
    *backpath=4;
}
void genFraq(){
    printf("randPaths...");
    fflush(stdout);
    
    do{
        randPath(0,FRAQSPLIT/2,FRAQSPLIT-1,FRAQSPLIT/2,fraqLR);
    }while(!checkPath(fraqLR));

    do{
        randPath(0,FRAQSPLIT/2,FRAQSPLIT/2,0,fraqLU);
    }while(!checkPath(fraqLU));
    
    do{
        randPath(0,FRAQSPLIT/2,FRAQSPLIT/2,FRAQSPLIT-1,fraqLD);
    }while(!checkPath(fraqLD));

    do{
        randPath(FRAQSPLIT-1,FRAQSPLIT/2,FRAQSPLIT/2,0,fraqRU);
    }while(!checkPath(fraqRU));
    do{
        randPath(FRAQSPLIT-1,FRAQSPLIT/2,FRAQSPLIT/2,FRAQSPLIT-1,fraqRD);
    }while(!checkPath(fraqRD));
    
    do{
        randPath(FRAQSPLIT/2,0,FRAQSPLIT/2,FRAQSPLIT-1,fraqUD);
    }while(!checkPath(fraqUD));
    printf("done!\n");
    fflush(stdout);
    printf("reverses...");
    fflush(stdout);
    
    reverse(fraqLR,fraqRL);
    reverse(fraqLU,fraqUL);
    reverse(fraqLD,fraqDL);
    reverse(fraqRU,fraqUR);
    reverse(fraqRD,fraqDR);
    reverse(fraqUD,fraqDU);
    printf("done!\n");
    fflush(stdout);
}

void initslcf(){
    printf("genFraq...");
    fflush(stdout);
    genFraq();
    initFraqTables();
    printf("done!\n");
    fflush(stdout);



}

int coord2direct(int x,int y){

    if(x==0){
        return 1;    
    }
    
    if(x==FRAQSPLIT-1){
       return 0;
    }
    
    if(y==0){
        return 2;
    }
    return 3;
    
}

void drawPath(SDL_Surface* screen,int ax1,int ay1,int ax2,int ay2,int color,char *path){
    int x1,y1,x2,y2,a,b,z,w,h;
     if(ax2-ax1<3 || ay2-ay1<3){
        setPixel(screen,(ax1+ax2)/2,(ay1+ay2)/2,color);
        printf("Setting %d %d\n",(ax1+ax2)/2,(ay1+ay2)/2);
        fflush(stdout);
        return;
    
    }
    
    if(path==NULL){
        printf("NULL\n");
        return;
        
    }
    printf("%p\n",path);
    fflush (stdout);
    printf("%d %d, %d %d -- %d %d, %d %d ::",ax1,ay1,ax2,ay2,(int)path[0],(int)path[1],(int)path[2],(int)path[3]);
    for(a=4;path[a]!=4;a++){
        printf("%d",(int)path[a]);
    }
    printf("\n");
    fflush(stdout);
    
   
        
    x1=*path;path++;
    y1=*path;path++;
    x2=*path;path++;
    y2=*path;path++;
    w=ax2-ax1;
    h=ay2-ay1;
    a=coord2direct(x1,y1);
    z=back(coord2direct(x2,y2));
    while(*path!=4){
        b=*path;
        drawPath(screen,ax1+x1*w/FRAQSPLIT,ay1+y1*h/FRAQSPLIT,ax1+(x1+1)*w/FRAQSPLIT-1,ay1+(y1+1)*h/FRAQSPLIT-1,color,fraqs[a][b]);
        switch(b){
            case 0:x1++; break;
            case 1:x1--; break;
            case 2:y1--; break;
            case 3:y1++; break;
        }
        a=back(b);
        path++;
    }
    drawPath(screen,ax1+x1*w/FRAQSPLIT,ay1+y1*h/FRAQSPLIT,ax1+(x1+1)*w/FRAQSPLIT-1,ay1+(y1+1)*h/FRAQSPLIT-1,color,fraqs[a][z]);
    
}

void swap(int &a,int &b){
    int t;
    t=a;
    a=b;
    b=t;
}

void drawslcf(SDL_Surface* screen){
    
    int h,w,hs,ws,x,y,i,j,xx,yy;
    int cch,ccw;
   
   
    SDL_FillRect(screen,NULL, 0x000000);
  
    drawPath(screen,0,0,128,128,WHITE,fraqUD);


    SDL_Flip( screen ); 
}
