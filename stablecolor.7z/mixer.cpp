

int mixerh=0;
int mixerw=0;
int *mixerbuf=NULL;
int *mul_mixerw;

void closeRgbMixer(){
    if(mixerbuf!=NULL){
        free(mixerbuf);
    }
    if(mul_mixerw!=NULL)
        free(mul_mixerw);
}

int ks0[256];
int ks1[256];
int ks2[256];

void calcKs(double alpha,int w,int mul){
    int x,xm;
    double sinalpha,cosalpha;
    double sinalpha2,cosalpha2;
    double sinalpha3,cosalpha3;
    sinalpha=sin(alpha)/255.;
    cosalpha=cos(alpha)/255.;
    sinalpha2=sin(alpha+2.0*M_PI/3.0)/255.;
    cosalpha2=cos(alpha+2.0*M_PI/3.0)/255.;
    sinalpha3=sin(alpha+4.0*M_PI/3.0)/255.;
    cosalpha3=cos(alpha+4.0*M_PI/3.0)/255.;
    
    for(x=0,xm=0;x<256;x++,xm+=mul){
        ks0[x]=4*(
        
                       (
                         (int)
                            (
                              sinalpha*xm
                            )
                       ) + 
                       (
                         (int)
                         (
                             (w+20)*
                             (
                                 (int)
                                 (
                                     cosalpha*xm
                                 )
                             )
                         )
                         
                       ) 
                            
                   );    //red shift
        ks1[x]=1+4*(
        
                        (
                          (int)
                          (
                             sinalpha2*xm)
                          )+ 
                          (
                                (int)(20+w)*
                                    (
                                       (int)(
                                             cosalpha2*xm
                                             )
                                       )
                    
                    
                          )
                    );   //green shift

        ks2[x]=2+4*(
                         (
                            (int)
                                   (    
                                      sinalpha3*xm
                                    )
                          )  +   
                          (
                              (int)
                              (20+w)*
                              (    (int)
                                  (
                                  cosalpha3*xm)
                                  )
                              
                           )   
                              );   //blue shift
        
        
   }


}

void  addNoise(SDL_Surface* s,int counts,int value,int colored){
    int i;
    struct rgb c;
    i=(s->w*s->h)*counts/100;
    if(value>255)
        value = 255;
    for(;i>0;i--){
        if(colored){
            c.r=rand()%value;
            c.g=rand()%value;
            c.b=rand()%value;
        }else{
            c.b=c.g=c.r=rand()%value;
        }
        plusPixel(s,rand()%s->w,rand()%s->h,*((Uint32*)(&c)));
    
    }
    
    
    


}

int fade(SDL_Surface* source,int div){
    int x,y;
    Uint8 d;
    struct rgb *p;
    if(div==255){
        SDL_FillRect(source,NULL, 0x000000);
        return 0;
    
    }
    d=div;
    p=(struct rgb *)( ((Uint8 *)source->pixels) + y * source->pitch);
    for(y=0;y<source->h;y++,p=(struct rgb *)( ((Uint8 *)source->pixels) + y * source->pitch))
        for(x=0;x<source->w;x++,p++){
            if(p->r>d){
                p->r-=d;
            }else{
                p->r=0;            
            }
            if(p->g>d){
                p->g-=d;
            }else{
                p->g=0;            
            }
            if(p->b>d){
                p->b-=d;
            }else{
                p->b=0;            
            }
        
        }


}

int rgbMixer(SDL_Surface* source,SDL_Surface* filter,int mul,double alpha){
    int x,y;
    int bpp = source->format->BytesPerPixel;
    int r,g,b,fr,fg,fb,dx,dy;
    SDL_Surface *f,*s,*d;
    int *bu;
  //  printf("mixer start\n");
   // fflush(stdout);
    if(mul<=0)
        return 0;
    if(mul>10)
        mul=10;
    if(source->w!=filter->w || source->h!=filter->h){
        if(mixerh!=-1){
           printf("Cant rgbMix, becouse screens are different\n");
           mixerh=-1;           
        }
        return -1;
    }
    if(mixerh!=filter->h || mixerw!=filter->w){

        if(mixerbuf!=NULL){
            free(mixerbuf);        
        }
        
        mixerbuf=(int*)malloc((filter->h+20)*(filter->w+20)*sizeof(int)*4);
        if(mixerbuf==NULL){
             printf("Cant rgbMix, becouse out of memory\n");
            return -2;
        }
        
        mixerh=filter->h;
        mixerw=filter->w;
       
    }
    memset(mixerbuf,0,(20+mixerh)*(20+mixerw)*4*sizeof(int));
    
   // bu=mixerbuf+(20+mixerw)*4*sizeof(int));
    calcKs(alpha,filter->w,mul);
    for(y=0;y<mixerh;y++){

        Uint32 *s =(Uint32 *)( (Uint8 *)source->pixels + y * source->pitch);
        Uint32 *f =(Uint32 *)( (Uint8 *)filter->pixels + y * filter->pitch);
        bu=mixerbuf+(((y+10)*(mixerw+20))+10)*4;
        for(x=mixerw-1;x;x--,bu+=4,f++,s++){
            if(!(*s) || !(*f)){
                continue;
            }
            pixel2rgb(*s,r,g,b);
            pixel2rgb(*f,fr,fg,fb);
            
            *s=0;
            bu[ks0[fr]]+=r;
            bu[ks1[fg]]+=g;
            bu[ks2[fb]]+=b;
            
        }
    }
    for(y=0;y<mixerh;y++){
        
        Uint32 *d =(Uint32*)( (Uint8 *)source->pixels + y * source->pitch);
        bu=mixerbuf+(((y+10)*(mixerw+20))+10)*4;
        for(x=mixerw-1;x;x--,bu++,d++){
            if(!((Uint32*)bu))
                continue;
            pixel2rgb(*d,r,g,b);
            r+=*bu;bu++;
            g+=*bu;bu++;
            b+=*bu;bu++;            
            if(r & (65535-255))
                r=255;           
            if(g& (65535-255))
                g=255;
            if(b& (65535-255))
                b=255;
            rgb2pixel(r,g,b,d);    
        }
    }

   // printf("mixer finish\n");
    //fflush(stdout);
    return 0;
}
