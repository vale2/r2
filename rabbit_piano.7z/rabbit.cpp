#define WINDOWCOMPILE 0
//#define WINDOWCOMPILE 8
void *__gxx_personality_v0;

#include "SDL/SDL.h"
//#include "SDL_opengl.h"
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <time.h> 
#define BUFSIZE 128
int msgid;

struct msgp {
    long mtype;
    char s[128];

};

void*modeData;
int mode,H,W;
//#include<sys/ipc.h>
//#include<sys/msg.h>
//#include <sys/types.h>
#define SVIDKEY 7373
#define min(x,y)  (((x)>(y))?(y):(x))
#include "graphutil.cpp"
//#include "netutil.cpp"
//#include "pipeutil.c"
//#include <sys/socket.h>

#include "snake.cpp"
//  GLuint texture; // Texture object handle
#include "hohloma.cpp"
#include "4d.cpp"
#include "barcode.cpp"
#include "slcf.cpp"
#include "piano.cpp"
#include "mixer.cpp"
//int SVIDanswer(const char*p);
void drawStars(SDL_Surface* screen){
    putpixel(screen,rand() % (screen->w),rand() % (screen->h),rand()); 
    SDL_Flip( screen ); 
}


Uint64 frames=0;
void draw(SDL_Surface* screen,SDL_Surface* filter){
   SDL_FillRect(screen,NULL, 0x000000);
   SDL_FillRect(filter,NULL, 0x000000);
   
   
    switch (mode){
        case 1: drawSnake(screen); break;   
        case 2: drawHohloma(screen); break;      
        case 3:draw4d(screen); break;
        case 4:drawbarcode(screen); break;
        case 5:drawPiano(screen);break;
        default: drawStars(screen); break;
    
    }
    
    drawPiano(filter);
    rgbMixer(screen,filter,10,frames*M_PI/20.0);
    SDL_Flip( screen ); 
    frames++;
}
void move(){
int i;
    switch(mode){
        case 1:for(i=0;i<3;i++) moveSnake();break;   
        case 2:moveHohloma();break;   
        case 3:move4d();break;
        case 4:movebarcode();break;   

    }


}
void setMode(int newMode,SDL_Surface* screen){
        if(mode==2&&newMode!=2){
            closeHohloma();     
        }
        if(mode == 3 && newMode!=3){
            close4d();
        }
        if(mode == 4 && newMode!=4){
            checkBars();
        }
        
        switch(newMode){
            case 1:if(mode==1)
                    break;
                    
                if(modeData!=NULL){
                    free(modeData);
                }
                modeData=malloc(2*sizeof(snake));
                if(modeData!=NULL){
                    mode=1;
                    zeroSnake();                    
                }
                break;
              case 2:if(mode==2)
                        break;
                    mode=2;
                    zeroHohloma(screen);
                break;  
              case 3:if(mode==3)
                        break;
                    mode=3;
                    init4d();
                break;  
                case 4:if(mode==4)
                        break;
                    mode=4;
                    initbarcode(screen);
                break; 
                case 5:if(mode==5)
                        break;
                    mode=5;
                   // initslcf();
                break;
              default:if(mode==newMode)
                        break;
                    if(modeData!=NULL){
                        free(modeData);
                       
                    }
                    modeData=NULL;
                    mode=newMode;
                   break;   
            
            
        }


}

void syntaxControll(char*p,SDL_Surface *screen){
    char term[128];
    char buf[128];
    int t1;
    printf("SyntaxControll:%s\n",p);
    while(*p){
        p+=sscanf(p,"%s",term);
        if(!strcmp(term,"getmode")){
            sprintf(buf,"mode %d\n",mode);
           // SVIDanswer(buf);
        }
        if(!strcmp(term,"setmode")){
            p+=sscanf(p,"%d",&t1);
            setMode(t1,screen);
       
            
        }
        if(!strcmp(term,"getConsts")){
            switch (mode){
                case 1:
                        while(*p){
                        /*
                             G=10;
                             L=0.0001;
                             M=0.001;
                             SNL=3;
                             K=0.001;
                             C=10;

                        
                        */
                        
                            p+=sscanf(p,"%s",term);
                            if(!strcmp(term,"g")){
                                p+=sscanf(p,"%lf",&G);
                            }
                            if(!strcmp(term,"l")){
                                p+=sscanf(p,"%lf",&L);
                            }
                            if(!strcmp(term,"m")){
                                p+=sscanf(p,"%lf",&M);
                            }    
                            if(!strcmp(term,"snl")){
                                p+=sscanf(p,"%lf",&SNL);
                            }
                            if(!strcmp(term,"k")){
                                p+=sscanf(p,"%lf",&K);
                            }
                            if(!strcmp(term,"c")){
                                p+=sscanf(p,"%lf",&C);
                            }
                        }
       
        
        
                break;
    
    
            }
       

        }
   
    }

}
/*

int SVIDquest(char*p){
    struct msgp a;
    a.mtype=1; 
    if(strlen(p)<128){
        strcpy(a.s,p);
        printf("SVID_QUEST_SENDING:(%s)\n",a.s);
        return msgsnd(msgid,&a,sizeof(struct msgp),IPC_NOWAIT);
    }
    return 1;        

}

int SVIDanswer(const char*p){
    struct msgp a;
    a.mtype=2; 
    if(strlen(p)<128){
        strncpy(a.s,p,127);
        printf("SVID_ANS_SENDING:(%s)\n",a.s);
        return msgsnd(msgid,&a,sizeof(struct msgp),IPC_NOWAIT);
    }
    return 1;       

}
int ifSVIDanswer(char*p){
    struct msgp a;
    int size;
    size= msgrcv(msgid,&a,sizeof(struct msgp),2,IPC_NOWAIT );
    if(size>0){
        printf("SVID_RCV_ANS:(%s)",a.s);
        strncpy(p,a.s,127);
    }
    return size;
}

int connect2SVID(){
    while(1){
        msgid = msgget(SVIDKEY, 0666);
        if (msgid == -1) {
            printf("Waiting for server\n", msgid);
            continue;
        }
        break;
    }
    return 0;
}
int startIpServer(){


    pid_t childPID = fork();

    if(childPID >= 0) // fork was successful
    {
        if(childPID == 0) // CHILD process
        {
            sleep(2); 
            ipserver(); 
            
        }         
    }else{
        printf("Ip server not forked\n");
        return 1;
    
    }    
    
    

    return 0;

}

int startSVIDServer(){
    return msgid = msgget(SVIDKEY, 0666 | IPC_CREAT);    
}
int setNetcontroll(){
    startSVIDServer();
    startIpServer();

}
*/
int controll(SDL_Surface *screen){
    SDL_Event event;
    char buf[BUFSIZE+1]="";
    int datasize;
    int msgid,size;
    struct msgp a;
    
   // size=msgrcv(msgid,&a,sizeof(struct msgp),1,IPC_NOWAIT );
    size=0;
    if(size>0 ){
         syntaxControll(a.s,screen);
     }
    
    
    
    if(mode==1 && checkLokalSnake() && !(rand()%200)){
        setMode(0,screen);
        setMode(1,screen);  
    
    }
    
   /* if(mode==1 && !(rand()%1000)  && !(rand()%30)){
        setMode(0,screen);
        setMode(1,screen);
    }*/
    
    
    while(SDL_PollEvent(&event)){
        switch (event.type) {
            case SDL_KEYDOWN: switch (event.key.keysym.scancode){
                              case 9-WINDOWCOMPILE: return 1; break;
                              case 10-WINDOWCOMPILE: setMode(0,screen); break;
                              case 11-WINDOWCOMPILE: setMode(1,screen); break;
                              case 12-WINDOWCOMPILE: setMode(2,screen); break;
                              case 13-WINDOWCOMPILE: setMode(3,screen); break;
                              case 14-WINDOWCOMPILE: setMode(4,screen); break;
                              case 15-WINDOWCOMPILE: setMode(5,screen); break;
                              case 27-WINDOWCOMPILE :      srand (time(NULL)); break;
                              default:printf("keydown:%d \n",event.key.keysym.scancode); break;
                              }    break;
            
            
            case SDL_QUIT: return 1; break;
           
        }
    }
    
    
     
    
    
    
    return 0;
}
int main( int argc, char* args[] ) { 
    int i,x,y,c,flag,windowflag,windowXRes,windowYRes;
    //The images 
    SDL_Surface* hello = NULL; 
    SDL_Surface* screen = NULL;
    SDL_Surface* filter = NULL;
    SDL_Surface *trueScreen = NULL ;
    const SDL_VideoInfo* myPointer;
    modeData=NULL;
    windowflag=0;
    flag=1;
    srand (time(NULL));
    SDL_putenv((char*)"SDL_VIDEO_WINDOW_POS=0,0");
     
    for(i=1;i<argc;i++){
        if(!strcmp(args[i],"-window") && i+1<argc){
            windowXRes=-1;
            windowYRes=-1;
            i++;
            sscanf(args[i],"%dx%d",&windowXRes,&windowYRes);
            if(windowXRes > 0 && windowYRes > 0 ){
                windowflag=1;  
                SDL_putenv((char*)"SDL_VIDEO_WINDOW_POS=50,50");
     
            }
        }
            
    
    }

    // initPipes();
     //Start SDL 
     SDL_Init( SDL_INIT_EVERYTHING ); 
     //Set up screen 
     
     
     
     myPointer = SDL_GetVideoInfo();
     W=myPointer->current_w;
     H=myPointer->current_h;
     if(windowflag){
        W=windowXRes;
        H=windowYRes;
     }        
     screen = SDL_SetVideoMode(W , H, 32, SDL_HWSURFACE |  (windowflag?0:SDL_NOFRAME) | SDL_DOUBLEBUF/*|SDL_GL_DOUBLEBUFFER |SDL_OPENGL */); 
     filter=cloneScreen(screen);
     if(filter==NULL){
        printf("Cant create filter surface\n");
     
     }
     SDL_ShowCursor(0);
     
     zerroTable();
     mode=0;
     G=6;
     L=0.0001;
     M=0.001;
     SNL=3;
     K=0.001;
     C=10;

     setMode(2,screen);
    // setNetcontroll();
     while(flag){
        //printf("draw\n");
       // fflush(stdout);
        draw(screen,filter);
        //printf("move\n");
       // fflush(stdout);
        for(i=0;i<4;i++)
            move();
        if(controll(screen)){
            break;
        }       
        
     }
     

     
      //Quit SDL 
      closeRgbMixer();
      SDL_Quit(); 
      return 0;
}
